function setup() {
  createCanvas(200, 200);
  
}

function draw() {
  background(80);
  
  noStroke();
rect(140, 90, 50, 50);
  
  rect(10, 90, 50, 50);
  strokeWeight(4);
stroke(200);
rect(135, 138, 60, 60);
rect(5, 138, 60, 60);
  strokeWeight(2);
stroke(40);
  line(20, 88, 20, 45);
line(145, 88, 155, 15);
line(185, 88, 175, 15);
  strokeWeight(5.0);
strokeCap(ROUND);
line(35, 86, 35, 30);

ellipse(165, 60,30, 30);
ellipse(165, 20,20, 20);
  strokeWeight(6); 
point(20, 45);
  strokeWeight(13); 
point(35, 30);
}

